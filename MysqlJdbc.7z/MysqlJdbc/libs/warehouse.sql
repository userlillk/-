/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.7.36-log : Database - warehousems
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`warehousems` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `warehousems`;

/*Table structure for table `basematerial` */

DROP TABLE IF EXISTS `basematerial`;

CREATE TABLE `basematerial` (
  `baseId` varchar(40) NOT NULL,
  `baseName` varchar(40) DEFAULT NULL,
  `baseModel` varchar(40) DEFAULT NULL,
  `baseClass` varchar(40) DEFAULT NULL,
  `baseUnit` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`baseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `basematerial` */

insert  into `basematerial`(`baseId`,`baseName`,`baseModel`,`baseClass`,`baseUnit`) values ('001','计算机','01','电子设备','台'),('002','电线','02','传输介质','50米/条'),('003','苹果','03','食物','个'),('004','鼠标','04','电子设备','个'),('005','1','1','1','1'),('007','1','1','11','1'),('008','1','1','1','1'),('11','1','1','1','1'),('111','111','111','11','111'),('77','1','1','1','11');

/*Table structure for table `inware` */

DROP TABLE IF EXISTS `inware`;

CREATE TABLE `inware` (
  `baseId` varchar(40) DEFAULT NULL,
  `number` varchar(40) DEFAULT NULL,
  `unitprice` varchar(40) DEFAULT NULL,
  `summoney` varchar(40) DEFAULT NULL,
  `inwaredate` varchar(40) DEFAULT NULL,
  `inpersonid` varchar(40) DEFAULT NULL,
  `okpersonid` varchar(40) DEFAULT NULL,
  `wareid` varchar(40) DEFAULT NULL,
  `remarks` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `inware` */

insert  into `inware`(`baseId`,`number`,`unitprice`,`summoney`,`inwaredate`,`inpersonid`,`okpersonid`,`wareid`,`remarks`) values ('001','计算机','01','电子设备','台','01','02','00001','1'),('002','电线','02','传输介质','50米/条','01','03','00003','1'),('003','苹果','03','食物','个','01','02','00001','1'),('004','鼠标','04','电子设备','个','01','02','00002','1'),('007','1','1','1','1','04','01','00001','1'),('007','1','1','1','1','04','03','00001',''),('008','1','1','1','1','04','03','00002','1'),('77','11','55','88','01','04','01','00001','写实'),('88','8','22','22','22','02','01','00003','8'),('008','1','1','1','1','02','01','00004','1'),('77','1','1','1','1','02','01','00001','1'),('77','1','1','1','1','02','01','00001','1'),('111','200','1','1','1','01','02','00004','1'),('11','1','1','1','1','02','01','00001','1');

/*Table structure for table `outware` */

DROP TABLE IF EXISTS `outware`;

CREATE TABLE `outware` (
  `baseId` varchar(40) DEFAULT NULL,
  `number` varchar(40) DEFAULT NULL,
  `unitprice` varchar(40) DEFAULT NULL,
  `summoney` varchar(40) DEFAULT NULL,
  `outwaredate` varchar(40) DEFAULT NULL,
  `outpersonid` varchar(40) DEFAULT NULL,
  `okpersonid` varchar(40) DEFAULT NULL,
  `wareid` varchar(40) DEFAULT NULL,
  `remarks` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `outware` */

insert  into `outware`(`baseId`,`number`,`unitprice`,`summoney`,`outwaredate`,`outpersonid`,`okpersonid`,`wareid`,`remarks`) values ('001','计算机','01','电子设备','台','01','02','00001','1'),('002','电线','02','传输介质','50米/条','01','03','00003','1'),('003','苹果','03','食物','个','01','02','00001','1'),('004','鼠标','04','电子设备','个','01','02','00002','1'),('111','100','1','1','01','01','01','00004','1'),('111','50','1','1','1','01','02','00004','1'),('111','50','1','50','1','01','04','00004','11');

/*Table structure for table `person` */

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `teleNumber` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `person` */

insert  into `person`(`id`,`name`,`teleNumber`) values ('01','张三','10086'),('02','李四','10010'),('03','王五','18866'),('04','赵六','17769');

/*Table structure for table `statistics` */

DROP TABLE IF EXISTS `statistics`;

CREATE TABLE `statistics` (
  `id` varchar(40) NOT NULL,
  `num` varchar(40) DEFAULT NULL,
  `unitprice` varchar(40) DEFAULT NULL,
  `summoney` varchar(40) DEFAULT NULL,
  `wareid` varchar(40) NOT NULL,
  PRIMARY KEY (`id`,`wareid`),
  KEY `wareid` (`wareid`),
  CONSTRAINT `statistics_ibfk_1` FOREIGN KEY (`id`) REFERENCES `basematerial` (`baseId`),
  CONSTRAINT `statistics_ibfk_2` FOREIGN KEY (`wareid`) REFERENCES `warehouse` (`wareId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `statistics` */

insert  into `statistics`(`id`,`num`,`unitprice`,`summoney`,`wareid`) values ('001','1','2','1','00001'),('002','1','2','1','00003'),('003','1','2','1','00002'),('004','1','2','1','00004'),('11','1','1','1','00001'),('111','0','1','1','00004');

/*Table structure for table `userandpwd` */

DROP TABLE IF EXISTS `userandpwd`;

CREATE TABLE `userandpwd` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) DEFAULT NULL,
  `teleNumber` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `userandpwd` */

insert  into `userandpwd`(`username`,`password`,`teleNumber`) values ('userLi','123456','1159'),('张三','8888','10086'),('李四','9999','10010');

/*Table structure for table `warehouse` */

DROP TABLE IF EXISTS `warehouse`;

CREATE TABLE `warehouse` (
  `wareId` varchar(40) NOT NULL,
  `wareName` varchar(40) DEFAULT NULL,
  `personId` varchar(40) DEFAULT NULL,
  `wareAddress` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`wareId`),
  KEY `personId` (`personId`),
  CONSTRAINT `warehouse_ibfk_1` FOREIGN KEY (`personId`) REFERENCES `person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `warehouse` */

insert  into `warehouse`(`wareId`,`wareName`,`personId`,`wareAddress`) values ('00001','计算机学院仓库','01','长山校区计算机学院楼'),('00002','电信信学院仓库','02','长山校区电信学院楼'),('00003','船海学院仓库','03','长山校区创海学院楼'),('00004','生物学院仓库','04','长山校区生物学院楼');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
