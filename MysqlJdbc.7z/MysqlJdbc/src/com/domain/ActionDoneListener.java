package com.domain;

public interface ActionDoneListener {

    void done(Object result);

}
