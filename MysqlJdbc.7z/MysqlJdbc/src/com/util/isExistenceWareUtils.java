package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//判断仓库是否存在       存在返回true
public class isExistenceWareUtils {
    public static boolean isExistenceWare(String wareId){
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from warehouse where wareId = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1,wareId);
            rs = pstmt.executeQuery();
            if(rs.next()){
                return true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally{
            MYSQLUtils.close(rs,pstmt,conn);
        }

        return false;
    }
}
