package com.util;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Properties;

/*
 *    jdbc 工具类  简化代码   将重复代码放在类中 的静态方法中
 */
public class MYSQLUtils {
    /*    需求不想传递参数  又想通用性  通过配置文件  文件的读取只要一次就可以
     *                                 使用静态代码块
     */
    private  static String url;
    private  static String user;
    private  static String password;
    private  static  String driver;

    static{
        //读取资源获取值
        //  Properties
        try {
            Properties pro = new Properties();

            //获取资源文件的绝对路径方法
            ClassLoader classLoader = MYSQLUtils.class.getClassLoader();
            URL res = classLoader.getResource("mysql.properties");
            String path = res.getPath();
//            System.out.println(path);

            //加载文件
//            pro.load(new FileReader("D:\\Java\\IDEA\\CommunityEdition\\java_study\\hello_app\\src\\jdbc.properties"));
            pro.load(new FileReader(path));

            url = pro.getProperty("url");
            user = pro.getProperty("user");
            password = pro.getProperty("password");
            driver = pro.getProperty("driver");
            /*System.out.println(url);
            System.out.println(user);
            System.out.println(password);
            System.out.println(driver);*/
            //注册驱动
            Class.forName(driver);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    /*
     * 获取连接
     * @return
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url,user,password);
    }

    //释放资源
    public static void close(Statement stmt,Connection conn){
        if(stmt!=null){
            try {
                stmt.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

    /*
     * 释放资源
     * @param stmt
     * @param conn
     */
    public static void close(ResultSet rs,Statement stmt, Connection conn){

        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        if(stmt!=null){
            try {
                stmt.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

}
