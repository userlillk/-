package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//判断物资编号是否已存在  几个判断存在可以合成一个  直接传入sql语言进行 更好的节约连接资源
public class isExistenceMaterialUtils {
    //存在  为  true
    public static boolean isExistenceMaterial(String baseId){
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from basematerial where baseId = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1,baseId);
            rs = pstmt.executeQuery();
            if(rs.next()){
                return true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally{
            MYSQLUtils.close(rs,pstmt,conn);
        }

        return false;
    }
}
