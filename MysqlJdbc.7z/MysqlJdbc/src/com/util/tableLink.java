package com.util;

import java.sql.*;
import java.util.Vector;

//完成两个表的连接
public class tableLink {
    //直接传入sql语句  获取顺序列的顺序    //也可采用select 获取顺序
    public static Vector<Vector> linkTableVector(String sql,String []titles){
        Vector<Vector> tableData = new Vector<>();
        Vector<String> title;
        Connection conn = null;
       Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            //获取一个表的列数
//            int length=rs.getMetaData().getColumnCount();

            while(rs.next()){
                title = new Vector<>();
                for (int i = 0; i < titles.length; i++) {
                    title.add(rs.getString(Integer.parseInt(titles[i])));
                }
                tableData.add(title);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,stmt,conn);
        }

        return tableData;
    };
}
