package com.util;
/*
    实现数据库读取的数据转入Vector中
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class ResultDatabase2Vector {
    //传入一个表名称
    public static Vector<Vector> converResultDatabase2Vector(String tableName){
        Vector<Vector> tableData = new Vector<>();
        Vector<String> title;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from "+tableName;


        try {
            conn = MYSQLUtils.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            //获取一个表的列数
            int length=rs.getMetaData().getColumnCount();

            while(rs.next()){
                title = new Vector<>();
                for (int i = 0; i < length; i++) {
                    title.add(rs.getString(i+1));
                }
                tableData.add(title);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,pstmt,conn);
        }

        return tableData;
    };
}
