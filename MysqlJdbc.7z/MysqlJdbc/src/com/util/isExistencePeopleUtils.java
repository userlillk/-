package com.util;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//判断员工是否存在   //存在返回true
public class isExistencePeopleUtils {

    public static boolean isExistencePeople(String personId){
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from person where id = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1,personId);
            rs = pstmt.executeQuery();
            if(rs.next()){
                return true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally{
            MYSQLUtils.close(rs,pstmt,conn);
        }

        return false;
    }
}
