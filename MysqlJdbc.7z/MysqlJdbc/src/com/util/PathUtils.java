package com.util;

//路径获取
public class PathUtils {

    private static final String P_PATH = "D:\\Java\\IDEA\\CommunityEdition\\MysqlJdbc\\imgs\\";

    public static String getRealPath(String relativePath){

        return P_PATH+relativePath;
    };
}
