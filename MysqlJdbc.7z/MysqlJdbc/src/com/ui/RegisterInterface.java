package com.ui;

import com.component.BackGroundPanel;
import com.util.MYSQLUtils;
import com.util.PathUtils;
import com.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//注册页面
public class RegisterInterface {
    JFrame jf = new JFrame("注册");

    final int WIDTH = 400;
    final int HEIGHT =400;

    public void init() throws IOException {
        //设置窗口的相关属性
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        jf.setResizable(false);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setIconImage(ImageIO.read(new File(PathUtils.getRealPath("xiaoHui.jpg"))));
        BackGroundPanel bgPanel = new BackGroundPanel(ImageIO.read(new File(PathUtils.getRealPath("register.png"))));

        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("用户名：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("密    码：");
        JTextField pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);

        Box nBox = Box.createHorizontalBox();
        JLabel nLabel = new JLabel("手机号：");
        JTextField nField = new JTextField(15);

        nBox.add(nLabel);
        nBox.add(Box.createHorizontalStrut(20));
        nBox.add(nField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton registBtn = new JButton("注册");
        JButton backBtn = new JButton("返回登录页面");

        //按钮的监听
        //注册按钮
        registBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取录入信息
                String username = uField.getText().trim();
                String password = pField.getText().trim();
                String teleNumber = nField.getText().trim();
                //访问数据库
                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    String sql = "select * from UserAndPwd where username = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1,username);
                    rs=pstmt.executeQuery();
                    //检查是否重复
                    if(rs.next()){
                        //检查是否有重复账号名  如果有
                        JOptionPane.showMessageDialog(jf,"账号已存在！");
                    }else{
                        //插入信息//注册成功 存储信息
                        String sql_1 = "insert into UserAndPwd values (?,?,?)";
                        pstmt = conn.prepareStatement(sql_1);
                        pstmt.setString(1,username);
                        pstmt.setString(2,password);
                        pstmt.setString(3,teleNumber);
                        pstmt.executeUpdate();
                        JOptionPane.showMessageDialog(jf,"注册成功，即将返回登录页面");
                        new MainInterface().init();
                        jf.dispose();
                    }
                } catch (SQLException | IOException throwables) {
                    throwables.printStackTrace();
                }finally {
                    MYSQLUtils.close(rs,pstmt,conn);
                }
            }
        });
        //返回按钮
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //返回登录页面
                try {
                    new MainInterface().init();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                jf.dispose();
            }
        });

        btnBox.add(registBtn);
        btnBox.add(Box.createHorizontalStrut(80));
        btnBox.add(backBtn);

        vBox.add(Box.createVerticalStrut(80));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(nBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(btnBox);

        bgPanel.add(vBox);
        jf.add(bgPanel);
        jf.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            new RegisterInterface().init();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
