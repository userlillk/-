package com.ui;

import com.component.Ware.WareManageComponen;
import com.component.material.baseMaterial.BaseManageComponen;
import com.component.material.inMateral.InManageComponen;
import com.component.material.outMaterial.OutManageComponen;
import com.component.material.statistics.StatisticsManageComponen;
import com.component.person.PersonManageComponent;
import com.util.PathUtils;
import com.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ManagerInterface {

    public ManagerInterface(String username){
        jf= new JFrame("科大库存管理系统："+username+"，欢迎您！");
    }

    public  ManagerInterface(){
        jf = new JFrame("科大库存管理系统：欢迎您！");
    }

    private JFrame jf=null;


    final int WIDTH = 1000;
    final int HEIGHT =600;

    public void init() throws IOException {
        //设置窗口的相关属性
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        jf.setResizable(false);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setIconImage(ImageIO.read(new File(PathUtils.getRealPath("xiaoHui.jpg"))));

        //设置菜单栏
        JMenuBar jmb = new JMenuBar();
        JMenu jMenu = new JMenu("设置");

        JMenuItem m1 = new JMenuItem("切换账号");
        JMenuItem m2 = new JMenuItem("退出程序");
        m1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new MainInterface().init();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                jf.dispose();
            }
        });
        m2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        jMenu.add(m1);
        jMenu.add(m2);
        jmb.add(jMenu);
        jf.setJMenuBar(jmb);

        //分割面板
        JSplitPane sp = new JSplitPane();
        sp.setContinuousLayout(true);        //支持连续布局
        sp.setDividerLocation(150);          //分隔条位置
        sp.setDividerSize(7);                //分隔条宽度

        //分割面板的左边  JTree
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("库存管理");
        DefaultMutableTreeNode wareManage = new DefaultMutableTreeNode("仓库管理");
        DefaultMutableTreeNode materialManage = new DefaultMutableTreeNode("物资管理");
        DefaultMutableTreeNode personnelManage  = new DefaultMutableTreeNode("人员管理");

        DefaultMutableTreeNode inWare  = new DefaultMutableTreeNode("入库管理");
        DefaultMutableTreeNode outWare  = new DefaultMutableTreeNode("出库管理");
        DefaultMutableTreeNode baseWare  = new DefaultMutableTreeNode("物资基本信息");
        DefaultMutableTreeNode stockWare  = new DefaultMutableTreeNode("物资库存信息");

        root.add(wareManage);
        root.add(materialManage);
        root.add(personnelManage);

        materialManage.add(baseWare);
        materialManage.add(inWare);
        materialManage.add(outWare);
        materialManage.add(stockWare);

        JTree tree = new JTree(root);
        Color color = new Color(203,220,217);
        MyRender myRender = new MyRender(); //图标
        myRender.setBackgroundNonSelectionColor(color);
        myRender.setBackgroundSelectionColor(new Color(140,140,140));
        tree.setCellRenderer(myRender);
        tree.setBackground(color);

        //设置默认选择人员管理
        tree.setSelectionRow(3);
        sp.setRightComponent(new PersonManageComponent(jf));
        tree.addTreeSelectionListener(new TreeSelectionListener() {
            //条目选择
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                //得到结点选中
                Object lastPathComponent = e.getNewLeadSelectionPath().getLastPathComponent();
                //判断
                if(wareManage.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new WareManageComponen(jf));
                }else if(materialManage.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new BaseManageComponen(jf));
                }else if(personnelManage.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new PersonManageComponent(jf));
                }else if(inWare.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new InManageComponen(jf));
                }else if(outWare.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new OutManageComponen(jf));
                }else if(baseWare.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new BaseManageComponen(jf));
                }else if(stockWare.equals(lastPathComponent)){

                    sp.setDividerLocation(150);          //分隔条位置
                    sp.setRightComponent(new StatisticsManageComponen(jf));
                }
            }
        });

        sp.setLeftComponent(tree);
        jf.add(sp);
        jf.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            new ManagerInterface().init();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //图标
    private class MyRender extends DefaultTreeCellRenderer{
        private ImageIcon rootIcon = null;
        private ImageIcon wareManageIcon = null;
        private ImageIcon materialManageIcon = null;
/*        private ImageIcon materialManageIcon1 = null;
        private ImageIcon materialManageIcon2 = null;
        private ImageIcon materialManageIcon3 = null;*/
        private ImageIcon personnelManageIcon = null;

        public MyRender(){
                rootIcon = new ImageIcon(PathUtils.getRealPath("systemManage.png"));
                wareManageIcon = new ImageIcon(PathUtils.getRealPath("userManage.png"));
                materialManageIcon = new ImageIcon(PathUtils.getRealPath("userManage.png"));
                personnelManageIcon = new ImageIcon(PathUtils.getRealPath("userManage.png"));
        }

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            ImageIcon image = null;
            switch (row){
                case 0:
                    image=rootIcon;
                    break;
                case 1:
                    image=wareManageIcon;
                    break;
                case 2:
                    image=materialManageIcon;
                    break;
                case 3:
                    image=personnelManageIcon;
                    break;
                default:
                    image = materialManageIcon;
                    break;
            }
            this.setIcon(image);
            return this;
        }
    }


}
