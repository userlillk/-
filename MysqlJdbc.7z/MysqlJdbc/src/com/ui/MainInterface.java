package com.ui;

import com.component.BackGroundPanel;
import com.util.MYSQLUtils;
import com.util.PathUtils;
import com.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.sql.*;

//程序入口  登录界面
public class MainInterface {
    JFrame jf = new JFrame("科大库存管理系统");

    final int WIDTH = 500;
    final int HEIGHT =300;

    //组装视图
    public void init() throws IOException {
        //设置窗口的相关属性
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        jf.setResizable(false);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setIconImage(ImageIO.read(new File(PathUtils.getRealPath("xiaoHui.jpg"))));
        BackGroundPanel bgPanel = new BackGroundPanel(ImageIO.read(new File(PathUtils.getRealPath("login.png"))));

        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("用户名：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("密    码：");
        JPasswordField pField = new JPasswordField(15);   //密码框

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);

        //按钮
        Box btnBox = Box.createHorizontalBox();
        JButton loginBtn = new JButton("登录");
        JButton registBtn = new JButton("注册");

        //按钮事件处理
        //登录按钮
        loginBtn.registerKeyboardAction(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取用户数据
                String username = uField.getText().trim();
                String password = pField.getText().trim();

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;
                //访问数据库 账号表查找是否存在
                try {

                    conn = MYSQLUtils.getConnection();
                    String sql = "select * from UserAndPwd where username = ? AND `password`= ?";
                    pstmt= conn.prepareStatement(sql);
                    //给 ?赋值
                    pstmt.setString(1,username);
                    pstmt.setString(2,password);
                    rs = pstmt.executeQuery();

                    if(rs.next()){//判断是否有下一行  有则登录成功

                        new ManagerInterface(username).init();
                        jf.dispose();
                    }else{
                        JOptionPane.showMessageDialog(jf,"用户名或密码错误！");
                    }

                } catch (SQLException | IOException throwables) {
                    throwables.printStackTrace();
                }finally {
                    //释放资源
                    MYSQLUtils.close(rs,pstmt,conn);
                }
            }
        },KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
        //设置快捷键
        //注册按钮
        registBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //跳转注册页面
                try {
                    new RegisterInterface().init();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                //当前界面消失
                jf.dispose();

            }
        });

        btnBox.add(loginBtn);
        btnBox.add(Box.createHorizontalStrut(100));
        btnBox.add(registBtn);

        vBox.add(Box.createVerticalStrut(60));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(50));
        vBox.add(btnBox);

        bgPanel.add(vBox);
        jf.add(bgPanel);
        jf.setVisible(true);
    }

    //客户程序的入口
    public static void main(String[] args) {
        try {
            new MainInterface().init();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
