package com.component.material.outMaterial;

import com.component.material.baseMaterial.UpdateMaterialDialog;
import com.component.material.inMateral.AddInRecordDialog;
import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.tableLink;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

//出库信息管理
public class OutManageComponen extends Box {
    final int WIDTH = 850;
    final int HEIGHT = 600;
    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;

    public OutManageComponen(JFrame jf) {
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组件
        this.jf = jf;
        init();
    }

    private void init(){
        //放按钮的JPanel
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(203,220,217));
        btnPanel.setMaximumSize(new Dimension(WIDTH,50));
        //从右布局
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("添加");

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹出对话框，输入信息
                new AddOutRecordDialog(jf, "添加出库信息", true, new ActionDoneListener() {
                    @Override
                    public void done(Object result) {
                        //刷新表格
                        requestData();
                    }
                }).setVisible(true);
            }
        });

        btnPanel.add(addBtn);

        this.add(btnPanel);

        //组装表格
        String[] ts = {"物资编号","物资名称","规格型号","类别","计量单位","数量","单价"
                ,"金额","出库时间","领用人","经办人","仓库","备注"};
        titles = new Vector<>();
        for (String title:ts
             ) {
            titles.add(title);
        }
        tableData = new Vector<>();

        tableModel = new DefaultTableModel(tableData,titles) {  //选中的是整行  不可编辑
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);

        //设置一次只能选一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        this.add(new JScrollPane(table));
        requestData();
    }

    //获取资源
    private void requestData(){
        String sql = "SELECT basematerial.`baseId`,basematerial.`baseName`," +
                "basematerial.`baseModel`,basematerial.`baseClass`,basematerial." +
                "`baseUnit`,outware.`number`,outware.`unitprice`,outware.`summoney`" +
                ",outware.`outwaredate`,a.`name`,B.name,warehouse.wareName,outware.`" +
                "remarks`FROM outware, basematerial, warehouse, person A,person" +
                " B WHERE outware.`baseId` = basematerial.`baseId` AND warehouse.wareId" +
                " = outware.`wareid` AND A.`id` = outware.`outpersonid` AND B.id = outware.`okpersonid`";
        String[] t ={"1","2","3","4","5","6","7","8","9","10","11","12","13"};
        Vector<Vector> temp = tableLink.linkTableVector(sql,t);
        //清空表格
        tableData.clear();
        for (Vector v :temp
                ) {
            tableData.add(v);
        }
        //刷新表格
        tableModel.fireTableDataChanged();
    }



}
