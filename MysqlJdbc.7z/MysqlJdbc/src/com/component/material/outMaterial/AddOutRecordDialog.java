package com.component.material.outMaterial;

import com.domain.ActionDoneListener;
import com.util.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//添加人员
public class AddOutRecordDialog extends JDialog {
    final int WIDTH = 600;
    final int HEIGHT = 300;
    private JFrame jf;
    //回调
    private ActionDoneListener listener;
                           //父窗口         模态          标题
    public AddOutRecordDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener){
        super(jf,title,isModel);
        this.jf = jf;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();
        Box vbBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("物资编号：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box abBox = Box.createHorizontalBox();
        JLabel abLabel = new JLabel("数        量：");
        JTextField abField = new JTextField(15);

        abBox.add(abLabel);
        abBox.add(Box.createHorizontalStrut(20));
        abBox.add(abField);


        Box bbBox = Box.createHorizontalBox();
        JLabel bbLabel = new JLabel("单        价：");
        JTextField bbField = new JTextField(15);

        bbBox.add(bbLabel);
        bbBox.add(Box.createHorizontalStrut(20));
        bbBox.add(bbField);

        Box cbBox = Box.createHorizontalBox();
        JLabel cbLabel = new JLabel("金        额：");
        JTextField cbField = new JTextField(15);

        cbBox.add(cbLabel);
        cbBox.add(Box.createHorizontalStrut(20));
        cbBox.add(cbField);

        Box dbBox = Box.createHorizontalBox();
        JLabel dbLabel = new JLabel("出库时间：");
        JTextField dbField = new JTextField(15);

        dbBox.add(dbLabel);
        dbBox.add(Box.createHorizontalStrut(20));
        dbBox.add(dbField);

        Box ebBox = Box.createHorizontalBox();
        JLabel ebLabel = new JLabel("领用人    ：");
        JTextField ebField = new JTextField(15);

        ebBox.add(ebLabel);
        ebBox.add(Box.createHorizontalStrut(20));
        ebBox.add(ebField);

        Box fbBox = Box.createHorizontalBox();
        JLabel fbLabel = new JLabel("经办人    ：");
        JTextField fbField = new JTextField(15);

        fbBox.add(fbLabel);
        fbBox.add(Box.createHorizontalStrut(20));
        fbBox.add(fbField);

        Box gbBox = Box.createHorizontalBox();
        JLabel gbLabel = new JLabel("仓        库：");
        JTextField gbField = new JTextField(15);

        gbBox.add(gbLabel);
        gbBox.add(Box.createHorizontalStrut(20));
        gbBox.add(gbField);

        Box hbBox = Box.createHorizontalBox();
        JLabel hbLabel = new JLabel("备        注：");
        JTextField hbField = new JTextField(15);

        hbBox.add(hbLabel);
        hbBox.add(Box.createHorizontalStrut(20));
        hbBox.add(hbField);

        JButton ok = new JButton("添加");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取录入信息
                String baseId = uField.getText().trim();         //物资id
                String number = abField.getText().trim();
                String unitprice = bbField.getText().trim();
                String summoney = cbField.getText().trim();
                String outwaredate = dbField.getText().trim();
                String outpersonid = ebField.getText().trim();
                String okpersonid = fbField.getText().trim();
                String wareid = gbField.getText().trim();
                String remarks = hbField.getText().trim();

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;
                try {
                    conn = MYSQLUtils.getConnection();
                    //判断物资编号是否已经存在
                    //判断入库人是否存在
                    //判断经办人是否存在
                    //判断仓库是否存在
                    if (!isExistencePeopleUtils.isExistencePeople(outpersonid)) {
                        JOptionPane.showMessageDialog(jf, "领用人不存在！");
                        return;
                    }
                    if (!isExistencePeopleUtils.isExistencePeople(okpersonid)) {
                        JOptionPane.showMessageDialog(jf, "经办人不存在！");
                        return;
                    }
                    if (!isExistenceWareUtils.isExistenceWare(wareid)) {
                        JOptionPane.showMessageDialog(jf, "仓库不存在！");
                        return;
                    }
                    if (!isExistenceMaterialUtils.isExistenceMaterial(baseId)) {
                        //不存在
                        JOptionPane.showMessageDialog(jf, "物资编号不存在！");
                        return;
                    }
                    if(!isExistenceStaUtils.isExistenceSta(baseId,wareid)){
                        //不存在
                        JOptionPane.showMessageDialog(jf, "库存不存在！");
                        return;
                    }

                    //查询出库存是否够
                    String findsql = "select statistics.num from statistics where id = ? and wareid = ?";
                    pstmt= conn.prepareStatement(findsql);
                    pstmt.setString(1, baseId);
                    pstmt.setString(2, wareid);
                    rs = pstmt.executeQuery();
                    rs.next();
                    String num = rs.getString(1);
                    int i = Integer.parseInt(num);
                    int j = Integer.parseInt(number);

                    if(i<j){ //库存不足
                        JOptionPane.showMessageDialog(jf, "库存不足，出库失败！");
                        return;
                    }
                    String sql = "update statistics set num = num - "+number+" where id = ? and wareid = ?";
                    pstmt =conn.prepareStatement(sql);
                    pstmt.setString(1,baseId);
                    pstmt.setString(2,wareid);
                    pstmt.executeUpdate();
                    //插入记录
                    String insertSql = "insert into outware values (?,?,?,?,?,?,?,?,?)";
                    pstmt = conn.prepareStatement(insertSql);
                    pstmt.setString(1, baseId);
                    pstmt.setString(2, number);
                    pstmt.setString(3, unitprice);
                    pstmt.setString(4, summoney);
                    pstmt.setString(5, outwaredate);
                    pstmt.setString(6, outpersonid);
                    pstmt.setString(7, okpersonid);
                    pstmt.setString(8, wareid);
                    pstmt.setString(9, remarks);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "添加成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "添加失败！");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs,pstmt, conn);
                }
            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(bbBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(abBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(cbBox);



        vbBox.add(Box.createVerticalStrut(20));
        vbBox.add(dbBox);
        vbBox.add(Box.createVerticalStrut(15));
        vbBox.add(ebBox);
        vbBox.add(Box.createVerticalStrut(15));
        vbBox.add(fbBox);
        vbBox.add(Box.createVerticalStrut(15));
        vbBox.add(gbBox);


        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vbBox);
        hBox.add(Box.createHorizontalStrut(20));
        Box box = Box.createVerticalBox();
        box.add(hBox);

        Box box1 = Box.createHorizontalBox();
        box1.add(Box.createHorizontalStrut(20));
        box1.add(hbBox);
        box1.add(Box.createHorizontalStrut(20));

        box.add(box1);
        box.add(ok);
        this.add(box);

    }

}
