package com.component.material.baseMaterial;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.isExistenceMaterialUtils;
import com.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//添加人员
public class AddMaterialDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 260;
    private JFrame jf;
    //回调
    private ActionDoneListener listener;
                           //父窗口         模态          标题
    public AddMaterialDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener){
        super(jf,title,isModel);
        this.jf = jf;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("物资编号：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("物资名称：");
        JTextField pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("规格型号：");
        JTextField tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);

        Box aBox = Box.createHorizontalBox();
        JLabel aLabel = new JLabel("类        别：");
        JTextField aField = new JTextField(15);

        aBox.add(aLabel);
        aBox.add(Box.createHorizontalStrut(20));
        aBox.add(aField);

        Box cBox = Box.createHorizontalBox();
        JLabel cLabel = new JLabel("计量单位：");
        JTextField cField = new JTextField(15);

        cBox.add(cLabel);
        cBox.add(Box.createHorizontalStrut(20));
        cBox.add(cField);

        JButton ok = new JButton("添加");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取录入信息
                String baseId = uField.getText().trim();         //物资id
                String baseName = pField.getText().trim();       //物资名称
                String baseModel = tField.getText().trim();       //规格型号
                String baseClass = aField.getText().trim();       //类别
                String baseUnit = cField.getText().trim();        //计量单位

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    //判断是否有存在  物资id
                    if (isExistenceMaterialUtils.isExistenceMaterial(baseId)) {
                        JOptionPane.showMessageDialog(jf, "物资编号已存在！");
                        return;
                    }
                    //插入
                    String insertSql = "insert into basematerial values (?,?,?,?,?)";
                    pstmt = conn.prepareStatement(insertSql);
                    pstmt.setString(1, baseId);
                    pstmt.setString(2, baseName);
                    pstmt.setString(3, baseModel);
                    pstmt.setString(4, baseClass);
                    pstmt.setString(5, baseUnit);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "添加成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "添加失败！");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs, pstmt, conn);
                }
            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(aBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(cBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);

    }

}
