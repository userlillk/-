package com.component.material.baseMaterial;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.isExistenceMaterialUtils;
import com.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//物资管理的修改
public class UpdateMaterialDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 260;
    private JFrame jf;
    private String id;  //传入的物资  id
    //回调
    private ActionDoneListener listener;

    private JTextField uField;
    private JTextField pField;
    private JTextField tField;
    private JTextField aField;
    private JTextField cField;

    //父窗口         模态          标题   键值
    public UpdateMaterialDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, String id){
        super(jf,title,isModel);
        this.jf = jf;
        this.id = id;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("物资编号：");
        uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("物资名称：");
        pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("规格型号：");
        tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);

        Box aBox = Box.createHorizontalBox();
        JLabel aLabel = new JLabel("类        别：");
        aField = new JTextField(15);

        aBox.add(aLabel);
        aBox.add(Box.createHorizontalStrut(20));
        aBox.add(aField);

        Box cBox = Box.createHorizontalBox();
        JLabel cLabel = new JLabel("计量单位：");
        cField = new JTextField(15);

        cBox.add(cLabel);
        cBox.add(Box.createHorizontalStrut(20));
        cBox.add(cField);

        JButton ok = new JButton("修改");
        //

        //处理修改
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取修改后的信息
                String baseId = uField.getText().trim();         //物资id
                String baseName = pField.getText().trim();       //物资名称
                String baseModel = tField.getText().trim();       //规格型号
                String baseClass = aField.getText().trim();       //类别
                String baseUnit = cField.getText().trim();        //计量单位

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    //先判断仓库id是否改变  如果没改变就只需要直接修改  否则先判断修改后的id是否跟表中的重复
                    if (!id.equals(baseId)) {  //改变
                        //判断是否有重复的 id
                        if (isExistenceMaterialUtils.isExistenceMaterial(baseId)) {
                            JOptionPane.showMessageDialog(jf, "仓库编号已存在！");
                            return;
                        }
                    }

                    //没有改变 或者 没有重复id
                    String updateSql = "update basematerial set baseId = ?,baseName = ?, baseModel = ?, baseClass = ?, baseUnit = ? where baseId = ?";
                    pstmt = conn.prepareStatement(updateSql);
                    pstmt.setString(1, baseId);
                    pstmt.setString(2, baseName);
                    pstmt.setString(3, baseModel);
                    pstmt.setString(4, baseClass);
                    pstmt.setString(5, baseUnit);
                    pstmt.setString(6, id);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "修改成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "修改失败！");
                    }

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs, pstmt, conn);
                }


            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(aBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(cBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);
        //获取数据
        requestData();
    }

    //获取数据
    public void requestData() {
        String baseId;         //物资id
        String baseName;       //物资名称
        String baseModel;       //型号
        String baseClass;    //物资类型
        String baseUnit;      //计量单位

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from basematerial where baseId = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1, id);

            rs = pstmt.executeQuery();
            rs.next(); //下一行开始读取
            baseId = rs.getString(1);
            baseName = rs.getString(2);
            baseModel = rs.getString(3);
            baseClass = rs.getString(4);
            baseUnit = rs.getString(5);

            uField.setText(baseId);
            pField.setText(baseName);
            tField.setText(baseModel);
            aField.setText(baseClass);
            cField.setText(baseUnit);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,pstmt,conn);
        }
    }
}
