package com.component.material.statistics;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.ScreenUtils;
import com.util.isExistenceWareUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//物资管理的修改
public class UpdateStaDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 260;
    private JFrame jf;
    private String id;  //传入的物资  id
    //回调
    private ActionDoneListener listener;

    private JTextField tField;
    private JTextField aField;
    private JTextField cField;
    private JTextField dField;

    //父窗口         模态          标题   键值
    public UpdateStaDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, String id){
        super(jf,title,isModel);
        this.jf = jf;
        this.id = id;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("数        量：");
        tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);

        Box aBox = Box.createHorizontalBox();
        JLabel aLabel = new JLabel("单        价：");
        aField = new JTextField(15);

        aBox.add(aLabel);
        aBox.add(Box.createHorizontalStrut(20));
        aBox.add(aField);

        Box cBox = Box.createHorizontalBox();
        JLabel cLabel = new JLabel("金        额：");
        cField = new JTextField(15);

        cBox.add(cLabel);
        cBox.add(Box.createHorizontalStrut(20));
        cBox.add(cField);

        Box dBox = Box.createHorizontalBox();
        JLabel dLabel = new JLabel("仓        库：");
        dField = new JTextField(15);

        dBox.add(dLabel);
        dBox.add(Box.createHorizontalStrut(20));
        dBox.add(dField);

        JButton ok = new JButton("修改");
        //

        //处理修改
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取修改后的信息
                String num = tField.getText().trim();       //个数
                String unitprice = aField.getText().trim();       //单价
                String summoney = cField.getText().trim();        //金额
                String wareid = dField.getText().trim();        //仓库

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    //判断是仓库号
                    if (!isExistenceWareUtils.isExistenceWare(wareid)) {
                        JOptionPane.showMessageDialog(jf, "仓库编号不存在！");
                        return;
                    }
                    //物资id 和 仓库id是主码  更改后如果存在 就添加
                    //没有改变 或者 没有重复id
                    String updateSql = "update statistics set num = ?,unitprice = ?, summoney = ? ,wareid = ? where id = ?";
                    pstmt = conn.prepareStatement(updateSql);
                    pstmt.setString(1, num);
                    pstmt.setString(2, unitprice);
                    pstmt.setString(3, summoney);
                    pstmt.setString(4, wareid);
                    pstmt.setString(5, id);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "修改成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "修改失败！");
                    }

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs, pstmt, conn);
                }
            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(aBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(cBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(dBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);
        //获取数据
        requestData();
    }

    //获取数据
    public void requestData() {
        String num;       //个数
        String unitprice;       //单价
        String summoney;        //金额
        String wareid;        //仓库

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select num,unitprice,summoney,wareid from statistics where id = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1, id);

            rs = pstmt.executeQuery();
            rs.next(); //下一行开始读取
            num = rs.getString(1);
            unitprice = rs.getString(2);
            summoney = rs.getString(3);
            wareid = rs.getString(4);

            tField.setText(num);
            aField.setText(unitprice);
            cField.setText(summoney);
            dField.setText(wareid);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,pstmt,conn);
        }
    }
}
