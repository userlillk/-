package com.component.material.inMateral;

import com.component.material.baseMaterial.UpdateMaterialDialog;
import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.tableLink;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

//入库信息管理
public class InManageComponen extends Box {
    final int WIDTH = 850;
    final int HEIGHT = 600;
    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;

    public InManageComponen(JFrame jf) {
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组件
        this.jf = jf;
        init();
    }

    private void init(){
        //放按钮的JPanel
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(203,220,217));
        btnPanel.setMaximumSize(new Dimension(WIDTH,50));
        //从右布局
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("添加");

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹出对话框，输入信息
                new AddInRecordDialog(jf, "添加入库信息", true, new ActionDoneListener() {
                    @Override
                    public void done(Object result) {
                        //刷新表格
                        requestData();
                    }
                }).setVisible(true);
            }
        });

        btnPanel.add(addBtn);


        this.add(btnPanel);

        //组装表格
        String[] ts = {"物资编号","物资名称","规格型号","类别","计量单位","数量","单价"
                ,"金额","入库时间","入库人","经办人","仓库","备注"};
        titles = new Vector<>();
        for (String title:ts
             ) {
            titles.add(title);
        }
        tableData = new Vector<>();

        tableModel = new DefaultTableModel(tableData,titles) {  //选中的是整行  不可编辑
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
/*        {    //这个选中是单个属性
            //设置不可编辑
            @Override
            public boolean isCellSelected(int row, int column) {
                return false;
            }
        };*/

        //设置一次只能选一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        this.add(new JScrollPane(table));
        requestData();
    }

    //获取资源
    private void requestData(){
        String sql = "SELECT basematerial.`baseId`,basematerial.`baseName`,basematerial" +
                ".`baseModel`,basematerial.`baseClass`,basematerial.`baseUnit`" +
                ",inware.`number`,inware.`unitprice`,inware.`summoney`,inware.`" +
                "inwaredate`,a.`name`,B.name,warehouse.wareName,inware.`remarks`FROM " +
                "inware, basematerial, warehouse, person A,person B WHERE inware.`baseId` " +
                "= basematerial.`baseId` AND warehouse.wareId =inware.`wareid` AND A.`id` = " +
                "inware.`inpersonid` AND B.id = inware.`okpersonid`";
        String[] t ={"1","2","3","4","5","6","7","8","9","10","11","12","13"};
        Vector<Vector> temp = tableLink.linkTableVector(sql,t);
        //清空表格
        tableData.clear();
        for (Vector v :temp
                ) {
            tableData.add(v);
        }
        //刷新表格
        tableModel.fireTableDataChanged();
    }
}
