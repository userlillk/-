package com.component.Ware;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.isExistencePeopleUtils;
import com.util.isExistenceWareUtils;
import com.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//添加人员
public class AddWareDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 230;
    private JFrame jf;
    //回调
    private ActionDoneListener listener;
                           //父窗口         模态          标题
    public AddWareDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener){
        super(jf,title,isModel);
        this.jf = jf;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("仓库编号    ：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("仓库名称    ：");
        JTextField pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("负责人编号：");
        JTextField tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);

        Box aBox = Box.createHorizontalBox();
        JLabel aLabel = new JLabel("仓库地址    ：");
        JTextField aField = new JTextField(15);

        aBox.add(aLabel);
        aBox.add(Box.createHorizontalStrut(20));
        aBox.add(aField);

        JButton ok = new JButton("添加");

        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取录入信息
                String wareID = uField.getText().trim();         //仓库id
                String wareName = pField.getText().trim();       //仓库名称
                String personID = tField.getText().trim();       //负责人编号
                String wareAddress = aField.getText().trim();    //仓库地址

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    //判断是否有存在  id
                    if (!isExistencePeopleUtils.isExistencePeople(personID)) {
                        JOptionPane.showMessageDialog(jf, "负责人编号不存在！");
                        return;
                    }

                    //判断编号是否已经存在
                    if(isExistenceWareUtils.isExistenceWare(wareID)){
                        JOptionPane.showMessageDialog(jf,"仓库编号已存在！");
                        return;
                    }else{
                        String insertSql = "insert into warehouse values (?,?,?,?)";
                        pstmt = conn.prepareStatement(insertSql);
                        pstmt.setString(1,wareID);
                        pstmt.setString(2,wareName);
                        pstmt.setString(3,personID);
                        pstmt.setString(4,wareAddress);

                        int count = pstmt.executeUpdate();
                        if(count>0){
                            JOptionPane.showMessageDialog(jf,"添加成功！");
                            dispose();
                            //回调
                            listener.done(null);
                        }else{
                            JOptionPane.showMessageDialog(jf,"添加失败！");
                        }
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }finally {
                    MYSQLUtils.close(rs,pstmt,conn);
                }


            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(aBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);

    }

}
