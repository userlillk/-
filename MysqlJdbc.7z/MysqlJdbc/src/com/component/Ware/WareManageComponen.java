package com.component.Ware;

import com.component.person.AddPersonDialog;
import com.component.person.UpdatePersonDialog;
import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.ResultDatabase2Vector;
import com.util.findUtils;
import com.util.tableLink;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

//人员管理
public class WareManageComponen extends Box {
    final int WIDTH = 850;
    final int HEIGHT = 600;
    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;

    public WareManageComponen(JFrame jf) {
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组件
        this.jf = jf;
        init();
    }

    private void init(){
        //放按钮的JPanel
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(203,220,217));
        btnPanel.setMaximumSize(new Dimension(WIDTH,50));
        //从右布局
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("添加");
        JButton deleteBtn = new JButton("删除");
        JButton updateBtn = new JButton("修改");
        JButton findBtn = new JButton("查找");
        JButton backBtn = new JButton("返回");
        JLabel uLabel = new JLabel("查找：");
        JTextField uField = new JTextField(10);

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹出对话框，输入信息
                new AddWareDialog(jf, "添加仓库信息", true, new ActionDoneListener() {
                    @Override
                    public void done(Object result) {
                        //刷新表格
                        requestData();
                    }
                }).setVisible(true);
            }
        });
        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取选中的id
                int selectedRow = table.getSelectedRow();

                if(selectedRow == -1){
                    JOptionPane.showMessageDialog(jf,"请选择要修改的条目");
                }else{
                    String id = tableModel.getValueAt(selectedRow,0).toString();
                    //弹出对话框，显示数据，让用户修改 ，在放入数据库
                    new UpdateWareDialog(jf, "修改仓库信息", true, new ActionDoneListener() {
                        @Override
                        public void done(Object result) {
                            requestData(); //刷新表格
                        }
                    },id).setVisible(true);
                }

            }
        });
        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取选中条目
                int selectedRow = table.getSelectedRow();
                if(selectedRow == -1){
                    JOptionPane.showMessageDialog(jf,"请选择要删除的条目");
                    return;
                }
                //防止误操作
                int result = JOptionPane.showConfirmDialog(jf, "确定要删除选择条目吗","确定删除" ,JOptionPane.YES_NO_OPTION);
                if(result != JOptionPane.YES_OPTION){
                    return;
                }
                String id = tableModel.getValueAt(selectedRow,0).toString();
                //删除
                Connection conn = null;
                PreparedStatement pstmt = null;

                try {
                    conn = MYSQLUtils.getConnection();
                    String sql = "delete from warehouse where wareId = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1,id);

                    int count = pstmt.executeUpdate();
                    if(count >= 1){
                        JOptionPane.showMessageDialog(jf,"删除成功");
                        //刷新表格
                        requestData();
                    }else{
                        JOptionPane.showMessageDialog(jf,"删除失败");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }finally {
                    MYSQLUtils.close(pstmt,conn);
                }
            }
        });
        findBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取ULabel内容
                String findText = uField.getText().trim();
                String sql = "SELECT warehouse.`wareId`,warehouse.`wareName`,person.`name`,person.`teleNumber`,warehouse.`wareAddress` " +
                        "FROM warehouse,person " +
                        "WHERE warehouse.`personId`=person.`id` and (wareId ="  +findText
                        +" or wareName ="+findText
                        +" or personId ="+findText
                        +" or wareAddress ="+findText +")";
                findData(sql);
            }
        });
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                requestData();
            }
        });

        btnPanel.add(Box.createHorizontalStrut(30));
        btnPanel.add(uLabel);
        btnPanel.add(Box.createHorizontalStrut(5));
        btnPanel.add(uField);
        btnPanel.add(findBtn);
        btnPanel.add(backBtn);
        btnPanel.add(Box.createHorizontalStrut(200));
        btnPanel.add(addBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(updateBtn);

        this.add(btnPanel);

        //组装表格
        String[] ts = {"仓库编号","仓库名称","负责人","联系电话","仓库地址"};
        titles = new Vector<>();
        for (String title:ts
             ) {
            titles.add(title);
        }
        tableData = new Vector<>();

        tableModel = new DefaultTableModel(tableData,titles) {  //选中的是整行
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
/*        {    //这个选中是单个属性
            //设置不可编辑
            @Override
            public boolean isCellSelected(int row, int column) {
                return false;
            }
        };*/

        //设置一次只能选一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        this.add(new JScrollPane(table));
        requestData();
    }

    //获取资源
    private void requestData(){
        String []t = {"1","2","3","4","5"};
        Vector<Vector> temp = tableLink.linkTableVector("SELECT warehouse.`wareId`,warehouse.`wareName`,person.`name`" +
                ",person.`teleNumber`,warehouse.`wareAddress` FROM warehouse,person " +
                "WHERE warehouse.`personId`=person.`id`", t);
        //清空表格
        tableData.clear();
        for (Vector v :temp
                ) {
            tableData.add(v);
        }
        //刷新表格
        tableModel.fireTableDataChanged();
    }

    private void findData(String sql){
        Vector<Vector> temp = findUtils.findIsExistence(sql);
        //清空表格
        tableData.clear();
        for (Vector v :temp
        ) {
            tableData.add(v);
        }
        //刷新表格
        tableModel.fireTableDataChanged();
    }

}
