package com.component.Ware;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.ScreenUtils;
import com.util.isExistencePeopleUtils;
import com.util.isExistenceWareUtils;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//人员管理的修改
public class UpdateWareDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 230;
    private JFrame jf;
    private String id;  //传入的仓库  id
    //回调
    private ActionDoneListener listener;

    private JTextField uField;
    private JTextField pField;
    private JTextField tField;
    private JTextField aField;

    //父窗口         模态          标题
    public UpdateWareDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, String id){
        super(jf,title,isModel);
        this.jf = jf;
        this.id = id;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("仓库编号    ：");
        uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("仓库名称    ：");
        pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("负责人编号：");
        tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);

        Box aBox = Box.createHorizontalBox();
        JLabel aLabel = new JLabel("仓库地址    ：");
        aField = new JTextField(15);

        aBox.add(aLabel);
        aBox.add(Box.createHorizontalStrut(20));
        aBox.add(aField);

        JButton ok = new JButton("修改");
        //

        //处理修改
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取修改后的信息
                //获取录入信息
                String wareID = uField.getText().trim();         //仓库id
                String wareName = pField.getText().trim();       //仓库名称
                String personID = tField.getText().trim();       //负责人编号
                String wareAddress = aField.getText().trim();    //仓库地址

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {

                    conn = MYSQLUtils.getConnection();
                    //判断负责人id是否存在
                    //判断是否有存在  人员id
                    if (!isExistencePeopleUtils.isExistencePeople(personID)) {
                        JOptionPane.showMessageDialog(jf, "负责人编号不存在！");
                        return;
                    }

                    //先判断仓库id是否改变  如果没改变就只需要直接修改  否则先判断修改后的id是否跟表中的重复
                    if (!id.equals(wareID)) {  //改变
                        //判断是否有重复的 id
                        if (isExistenceWareUtils.isExistenceWare(wareID)) {
                            JOptionPane.showMessageDialog(jf, "仓库编号已存在！");
                            return;
                        }
                    }  //

                    //没有改变 或者 没有重复id
                    String updateSql = "update warehouse set wareId = ?,wareName = ?, personId = ?, wareAddress = ? where wareId = ?";
                    pstmt = conn.prepareStatement(updateSql);
                    pstmt.setString(1, wareID);
                    pstmt.setString(2, wareName);
                    pstmt.setString(3, personID);
                    pstmt.setString(4, wareAddress);
                    pstmt.setString(5, id);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "修改成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "修改失败！");
                    }

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs, pstmt, conn);
                }


            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(aBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);
        //获取数据
        requestData();
    }

    //获取数据
    public void requestData() {
        String wareID;         //仓库id
        String wareName;       //仓库名称
        String personID;       //负责人编号
        String wareAddress;    //仓库地址

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from warehouse where wareId = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1, id);

            rs = pstmt.executeQuery();
            rs.next(); //下一行开始读取
            wareID = rs.getString(1);
            wareName = rs.getString(2);
            personID = rs.getString(3);
            wareAddress = rs.getString(4);

            uField.setText(wareID);
            pField.setText(wareName);
            tField.setText(personID);
            aField.setText(wareAddress);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,pstmt,conn);
        }
    }
}
