package com.component.person;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.isExistencePeopleUtils;
import com.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//添加人员
public class AddPersonDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 200;
    private JFrame jf;
    //回调
    private ActionDoneListener listener;
                           //父窗口         模态          标题
    public AddPersonDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener){
        super(jf,title,isModel);
        this.jf = jf;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("人员编号：");
        JTextField uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("姓        名：");
        JTextField pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("电        话：");
        JTextField tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);
        JButton ok = new JButton("添加");

        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取录入信息
                String id = uField.getText().trim();
                String name = pField.getText().trim();
                String teleNumber = tField.getText().trim();

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    conn = MYSQLUtils.getConnection();

                    //判断编号是否已经存在
                    if(isExistencePeopleUtils.isExistencePeople(id)){
                        JOptionPane.showMessageDialog(jf,"编号已存在！");
                    }else{
                        String insertSql = "insert into person values (?,?,?)";
                        pstmt = conn.prepareStatement(insertSql);
                        pstmt.setString(1,id);
                        pstmt.setString(2,name);
                        pstmt.setString(3,teleNumber);
                        int count = pstmt.executeUpdate();
                        if(count>0){
                            JOptionPane.showMessageDialog(jf,"添加成功！");
                            dispose();
                            //回调
                            listener.done(null);
                        }else{
                            JOptionPane.showMessageDialog(jf,"添加失败！");
                        }
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }finally {
                    MYSQLUtils.close(rs,pstmt,conn);
                }


            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);

    }
}
