package com.component.person;

import com.domain.ActionDoneListener;
import com.util.MYSQLUtils;
import com.util.isExistencePeopleUtils;
import com.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//人员管理的修改
public class UpdatePersonDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 200;
    private JFrame jf;
    private String id;
    //回调
    private ActionDoneListener listener;

    private JTextField uField;
    private JTextField pField;
    private JTextField tField;

    //父窗口         模态          标题
    public UpdatePersonDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener,String id){
        super(jf,title,isModel);
        this.jf = jf;
        this.id = id;
        this.listener = listener;
        init();
    }

    public void init(){
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        //设置关闭JDialog
        this.setDefaultCloseOperation(1);
        //组装登录相关元素
        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("人员编号：");
        uField = new JTextField(15);

        uBox.add(uLabel);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(uField);

        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("姓        名：");
        pField = new JTextField(15);

        pBox.add(pLabel);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(pField);


        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("电        话：");
        tField = new JTextField(15);

        tBox.add(tLabel);
        tBox.add(Box.createHorizontalStrut(20));
        tBox.add(tField);
        JButton ok = new JButton("修改");
        //

        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取修改后的信息
                String ID = uField.getText().trim();
                String Name = pField.getText().trim();
                String TeleNumber = tField.getText().trim();

                Connection conn = null;
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                try {
                    //先判断id是否改变  如果没改变就只需要直接修改  否则先判断修改后的id是否跟表中的重复
                    conn = MYSQLUtils.getConnection();
                    if (!id.equals(ID)) {  //改变
                        //判断是否有重复的 id
                        if (isExistencePeopleUtils.isExistencePeople(id)) {
                            JOptionPane.showMessageDialog(jf, "编号已存在！");
                            return;
                        }
                    }  //

                    //没有改变 或者 没有重复id
                    String updateSql = "update person set id = ?,name = ?, teleNumber = ? where id = ?";
                    pstmt = conn.prepareStatement(updateSql);
                    pstmt.setString(1, ID);
                    pstmt.setString(2, Name);
                    pstmt.setString(3, TeleNumber);
                    pstmt.setString(4, id);

                    int count = pstmt.executeUpdate();
                    if (count > 0) {
                        JOptionPane.showMessageDialog(jf, "修改成功！");
                        dispose();
                        //回调
                        listener.done(null);
                    } else {
                        JOptionPane.showMessageDialog(jf, "修改失败！");
                    }

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } finally {
                    MYSQLUtils.close(rs, pstmt, conn);
                }


            }
        });

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ok);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));
        this.add(hBox);
        //获取数据
        requestData();
    }

    //获取数据
    public void requestData() {
        String ID;
        String Name;
        String TeleNumber;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MYSQLUtils.getConnection();
            String isFindSql = "select * from person where id = ?";
            pstmt = conn.prepareStatement(isFindSql);
            pstmt.setString(1, id);

            rs = pstmt.executeQuery();
            rs.next(); //下一行开始读取
            ID = rs.getString(1);
            Name = rs.getString(2);
            TeleNumber = rs.getString(3);

            uField.setText(ID);
            pField.setText(Name);
            tField.setText(TeleNumber);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            MYSQLUtils.close(rs,pstmt,conn);
        }
    }
}
